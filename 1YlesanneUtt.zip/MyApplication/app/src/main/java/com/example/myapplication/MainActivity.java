package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import static com.example.myapplication.Quiz.quiz;

public class MainActivity extends AppCompatActivity {

    ImageView picture;
    TextView TextViewQuestion;
    Button button1;
    Button button2;
    Button button3;
    Button buttonRight;
    Boolean rightAnswer = false;

    int n = 0;
    int total=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        picture = findViewById(R.id.imageView);
        TextViewQuestion = findViewById(R.id.TextViewQuestion);
        button1 = findViewById(R.id.buttonAnswer1);
        button2 = findViewById(R.id.buttonAnswer2);
        button3 = findViewById(R.id.buttonAnswer3);
        buttonRight = findViewById(R.id.buttonRightAnswer);
        buttonRight.setText("View right answer");
        Button buttonPortrait = (Button)findViewById(R.id.buttonPortrait);
        buttonPortrait.setText("Portrait orientation");
        Button buttonLandscape = (Button)findViewById(R.id.buttonLandscape);
        buttonLandscape.setText("Landscape orientation");


        final List<Question> questions = quiz;
        int resourceImage = getResources().getIdentifier(questions.get(n).getImage(), "drawable", getPackageName());
        picture.setImageResource(resourceImage);
        TextViewQuestion.setText(questions.get(n).getQuestion());
        button1.setText(questions.get(n).getAnswers()[0]);
        button2.setText(questions.get(n).getAnswers()[1]);
        button3.setText(questions.get(n).getAnswers()[2]);

        buttonRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rightAnswer = true;
                buttonRight.setText("True answer is " + questions.get(n).getTrueAnswer());
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (button1.getText().equals(questions.get(n).getTrueAnswer()) && !rightAnswer) {
                    total = total + 10;
                    Toast.makeText(getApplicationContext(), "True answer", Toast.LENGTH_LONG).show();
                } else {
                    if (!rightAnswer)
                        total = total - 5;
                    Toast.makeText(getApplicationContext(), "False answer", Toast.LENGTH_LONG).show();
                    if (rightAnswer)
                        Toast.makeText(getApplicationContext(), "True answer", Toast.LENGTH_LONG).show();
                }
                rightAnswer = false;
                buttonRight.setText("View right answer");
                n++;
                if (n == questions.size()) {
                    //public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, TestActivity.class);
                    intent.putExtra("TOTAL", total);
                    //getIntent().putExtra(MainActivity.TOTAL,total);
                    startActivity(intent);
                    finish();

                } else {
                    TextViewQuestion.setText(questions.get(n).getQuestion());
                    button1.setText(questions.get(n).getAnswers()[0]);
                    button2.setText(questions.get(n).getAnswers()[1]);
                    button3.setText(questions.get(n).getAnswers()[2]);
                    int resourceImage = getResources().getIdentifier(questions.get(n).getImage(), "drawable", getPackageName());
                    picture.setImageResource(resourceImage);
                }
            }
        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (button2.getText().equals(questions.get(n).getTrueAnswer()) && !rightAnswer) {
                    total = total + 10;
                    Toast.makeText(getApplicationContext(), "True answer", Toast.LENGTH_LONG).show();
                } else {
                    if (!rightAnswer)
                        total = total - 5;
                    Toast.makeText(getApplicationContext(), "False answer", Toast.LENGTH_LONG).show();
                    if (rightAnswer)
                        Toast.makeText(getApplicationContext(), "True answer", Toast.LENGTH_LONG).show();
                }
                rightAnswer = false;
                buttonRight.setText("View right answer");
                n++;
                if (n == questions.size()) {
                    //public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, TestActivity.class);
                    intent.putExtra("TOTAL", total);
                    //getIntent().putExtra(MainActivity.TOTAL,total);
                    startActivity(intent);
                    finish();

                } else {
                    TextViewQuestion.setText(questions.get(n).getQuestion());
                    button1.setText(questions.get(n).getAnswers()[0]);
                    button2.setText(questions.get(n).getAnswers()[1]);
                    button3.setText(questions.get(n).getAnswers()[2]);
                    int resourceImage = getResources().getIdentifier(questions.get(n).getImage(), "drawable", getPackageName());
                    picture.setImageResource(resourceImage);
                }

            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (button3.getText().equals(questions.get(n).getTrueAnswer()) && !rightAnswer) {
                    total = total + 10;
                    Toast.makeText(getApplicationContext(), "True answer", Toast.LENGTH_LONG).show();
                } else {
                    if (!rightAnswer)
                        total = total - 5;
                    Toast.makeText(getApplicationContext(), "False answer", Toast.LENGTH_LONG).show();
                    if (rightAnswer)
                        Toast.makeText(getApplicationContext(), "True answer", Toast.LENGTH_LONG).show();
                }
                rightAnswer = false;
                buttonRight.setText("View right answer");
                n++;
                if (n == questions.size()) {
                    //public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, TestActivity.class);
                    intent.putExtra("TOTAL", total);
                    //getIntent().putExtra(MainActivity.TOTAL,total);
                    startActivity(intent);
                    finish();

                } else {
                    TextViewQuestion.setText(questions.get(n).getQuestion());
                    button1.setText(questions.get(n).getAnswers()[0]);
                    button2.setText(questions.get(n).getAnswers()[1]);
                    button3.setText(questions.get(n).getAnswers()[2]);
                    int resourceImage = getResources().getIdentifier(questions.get(n).getImage(), "drawable", getPackageName());
                    picture.setImageResource(resourceImage);
                }

            }
        });
            buttonPortrait.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                }
            });
            buttonLandscape.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setRequestedOrientation((ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE));
                }
            });
        }
    }

