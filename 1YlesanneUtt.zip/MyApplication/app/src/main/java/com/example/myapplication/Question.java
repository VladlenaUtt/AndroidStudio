package com.example.myapplication;

import android.widget.ImageView;

public class Question {
    //String[] quiz;
    String[] answers;
    String image;
    String question;
    String trueAnswer;
    int id;

    public Question(int id, String question, String[] answers, String trueAnswer, String image) {

        //this.quiz = quiz;
        this.answers = answers;
        this.image = image;
        this.question = question;
        this.trueAnswer = trueAnswer;
        this.id = id;
    }



    public String[] getAnswers() {
        return answers;
    }

    public String getImage() {
        return image;
    }

    public String getQuestion() {
        return question;
    }

    public String getTrueAnswer() {
        return trueAnswer;
    }

    public int getId() {
        return id;
    }



    public void setAnswers(String[] answers) {
        this.answers = answers;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public void setTrueAnswer(String trueAnswer) {
        this.trueAnswer = trueAnswer;
    }

    public void setId(int id) {
        this.id = id;
    }
}


