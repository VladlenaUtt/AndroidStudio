package com.example.myapplication;

import java.util.ArrayList;
import java.util.List;

public class Quiz {
    public static List<Question> quiz=new ArrayList<>();
    static{
        quiz.add(new Question(1,"The capital of Estonia?",new String[] {"Tallinn","Riga","Vilnius"},"Tallinn","tallinn"));
        quiz.add(new Question(2, "What is the highest mountain in the world?",new String[] {"Himalchung", "Everest","Makalu"},"Everest","everest"));
        quiz.add(new Question(3, "Who is the heaviest living animal in the world?",new String[] {"Elephant","Blue whale","Hippopotamus"},"Blue whale","bluewhale"));
        quiz.add(new Question(4, "What is the population in Estonia?",new String[] {"1.329mln","1.250mln","1.436mln"}, "1.329mln", "estonia"));
        quiz.add(new Question(5, "What is the longest river in the world?", new String[] {"Mississippi","Amazon","Nile"}, "Nile","river"));
        quiz.add(new Question(6, "What is the largest continent?", new String[] {"Europe","Asia","Australia"}, "Asia","continent"));
        quiz.add(new Question(7, "Who is the president of France?", new String[] {"E.Macron","N.Sarkozy","F.Hollande"}, "E.Macron","president"));
        quiz.add(new Question(8, "Who is the most dangerous animal in the world?", new String[] {"Cape buffalo","Mosquito","Humans"}, "Humans","animal"));
        quiz.add(new Question(9, "What was the weight of the heaviest man in the world?", new String[] {"442","356","403"}, "442","fatman"));
        quiz.add(new Question(10, "What was the height of the tallest man in the world?", new String[] {"2.54m","2.72m","2.96m"}, "2.72m","tallman"));
    }
}

