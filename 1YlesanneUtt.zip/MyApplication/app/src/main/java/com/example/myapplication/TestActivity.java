package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import static com.example.myapplication.Quiz.quiz;

public class TestActivity extends AppCompatActivity {
    TextView Result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Result=findViewById(R.id.TOTAL);
        //int total = getIntent(quiz.total)//intent.getIntExtra(Quiz.SCORE, 0)
        int total = getIntent().getExtras().getInt("TOTAL");
        //const total = getIntent().getIntExtra(quiz.TOTAL);
        //txt.setText();
        TextView textView = findViewById(R.id.TOTAL);
        textView.setText("Your score is:" + total);
    }
}