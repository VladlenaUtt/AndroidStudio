package com.example.ulesanne4utt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.ulesanne4utt.adapters.DetailAdapter;
import com.example.ulesanne4utt.api.ApiFactory;
import com.example.ulesanne4utt.api.ApiService;
import com.example.ulesanne4utt.pojo.Info;
import com.example.ulesanne4utt.presenters.DataListView;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class DetailActivity extends AppCompatActivity implements DataListView<Info> {

    private RecyclerView recyclerViewInfo;
    private DetailAdapter adapter;
    Disposable disposable;
    CompositeDisposable compositeDisposable;
    Activity activity = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        recyclerViewInfo = findViewById(R.id.recyclerViewDetail);
        activity.setTitle("Room info");
        adapter = new DetailAdapter();
        adapter.setRoomInfo(new ArrayList<Info>());
        recyclerViewInfo.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewInfo.setAdapter(adapter);
        Intent intent = getIntent();
        String room = intent.getStringExtra("room");

        ApiFactory apiFactory=ApiFactory.getInstance();
        ApiService apiService=apiFactory.getApiService();
        compositeDisposable=new CompositeDisposable();
        disposable=apiService.getInfo(room)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<JsonArray>() {
                    @Override
                    public void accept(JsonArray object) throws Exception {
                        Type typeToken = new TypeToken<List<Info>>() {}.getType();
                        List<Info> item = new Gson().fromJson(object, typeToken);
                        adapter.setRoomInfo(item);
                        // Log.e("Data: ", object.toString());
                        // Log.e("Data: ", String.valueOf(item));

                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Toast.makeText(DetailActivity.this, throwable.getMessage(),
                                Toast.LENGTH_SHORT).show();
                        Log.e("MyError", throwable.getMessage());
                    }
                });
        compositeDisposable.add(disposable);
    }
    @Override
    protected void onDestroy() {
        if (compositeDisposable!=null)
            compositeDisposable.dispose();
        super.onDestroy();
    }

    @Override
    public void showData(List item) {
        adapter.setRoomInfo(item);
    }

    @Override
    public void showError() {
        Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
    }
}