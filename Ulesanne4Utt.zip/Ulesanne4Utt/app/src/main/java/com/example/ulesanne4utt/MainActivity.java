package com.example.ulesanne4utt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.Toast;
import com.example.ulesanne4utt.adapters.RoomAdapter;
import com.example.ulesanne4utt.api.ApiFactory;
import com.example.ulesanne4utt.api.ApiService;

import com.example.ulesanne4utt.pojo.Room;
import com.example.ulesanne4utt.presenters.DataListView;
import com.example.ulesanne4utt.presenters.MainPresenter;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity implements DataListView {

    private RecyclerView recyclerViewRoom;
    private RoomAdapter adapter;
    Disposable disposable;
    CompositeDisposable compositeDisposable;
    private MainPresenter presenter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerViewRoom = findViewById(R.id.recyclerViewRooms);
        adapter = new RoomAdapter();
        adapter.setRooms(new ArrayList<Room>());
        recyclerViewRoom.setLayoutManager(new GridLayoutManager(this, getColumnCount()));
        recyclerViewRoom.setAdapter(adapter);
        presenter = new MainPresenter(this);
        presenter.loadData();
        ApiFactory apiFactory=ApiFactory.getInstance();
        ApiService apiService=apiFactory.getApiService();
        compositeDisposable=new CompositeDisposable();
        disposable=apiService.getRooms()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<JsonArray>() {
                    @Override
                    public void accept(JsonArray object) throws Exception {
                        Type typeToken = new TypeToken<List<Room>>() {}.getType();
                        List<Room> items = new Gson().fromJson(object, typeToken);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Toast.makeText(MainActivity.this, throwable.getMessage(),
                                Toast.LENGTH_SHORT).show();
                        Log.e("MyError", throwable.getMessage());
                    }
                });
        compositeDisposable.add(disposable);
    }
    private int getColumnCount() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = (int) (displayMetrics.widthPixels / displayMetrics.density);
        return width / 185 > 2 ? width / 185 : 2;
    }
    @Override
    protected void onDestroy() {
        if (compositeDisposable!=null)
            compositeDisposable.dispose();
        super.onDestroy();
    }

    @Override
    public void showData(List items) {
        adapter.setRooms(items);
    }

    @Override
    public void showError() {
        Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
    }
}