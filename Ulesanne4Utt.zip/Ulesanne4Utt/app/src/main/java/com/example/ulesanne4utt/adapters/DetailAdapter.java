package com.example.ulesanne4utt.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ulesanne4utt.R;
import com.example.ulesanne4utt.pojo.Info;

import java.util.List;

public class DetailAdapter extends RecyclerView.Adapter<DetailAdapter.InfoHolder> {
    private List<Info> detailList;

    public List<Info> getInfo() {
        return detailList;
    }

    public void setRoomInfo(List<Info> detailList) {
        this.detailList = detailList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DetailAdapter.InfoHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.detail_item,
                parent, false);
        return new DetailAdapter.InfoHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DetailAdapter.InfoHolder holder, int position) {
        Info info = detailList.get(position);
        holder.textViewRoomInfo.setText("Sensor: " + info.getSensor() + "\n" +
                "Value type: " + info.getValuetype() + "\n" + "Date: " + info.getLastDate() + "\n" + "Dimension: " +
                info.getDimension() + "\n" + "Data Value: " + info.getDatavalue());
    }

    @Override
    public int getItemCount() {
        return detailList.size();
    }

    class InfoHolder extends RecyclerView.ViewHolder {
        private TextView textViewRoomInfo;

        private InfoHolder(@NonNull View itemView) {
            super(itemView);
            textViewRoomInfo = itemView.findViewById(R.id.textViewDetail);
        }
    }
}
