package com.example.ulesanne4utt.api;

import com.google.gson.JsonArray;
import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiService {
    @GET("api/room")
    Observable<JsonArray> getRooms();

    @GET("api/room/{room}/currentall")
    Observable<JsonArray> getInfo(@Path("room") String roomname);


}
