package com.example.ulesanne4utt.pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Info {
    @SerializedName("controllersensorid")
    @Expose
    private Integer controllersensorid;
    @SerializedName("sensor_id")
    @Expose
    private Integer sensorId;
    @SerializedName("sensor")
    @Expose
    private String sensor;
    @SerializedName("sensortype")
    @Expose
    private String sensortype;
    @SerializedName("room")
    @Expose
    private String room;
    @SerializedName("controller_id")
    @Expose
    private Integer controllerId;
    @SerializedName("controller")
    @Expose
    private String controller;
    @SerializedName("last_date")
    @Expose
    private String lastDate;
    @SerializedName("valuetype")
    @Expose
    private String valuetype;
    @SerializedName("dimension")
    @Expose
    private String dimension;
    @SerializedName("typevalueid")
    @Expose
    private Integer typevalueid;
    @SerializedName("datavalue")
    @Expose
    private String datavalue;
    @SerializedName("picture")
    @Expose
    private String picture;

    public Integer getControllersensorid() {
        return controllersensorid;
    }

    public void setControllersensorid(Integer controllersensorid) {
        this.controllersensorid = controllersensorid;
    }

    public Integer getSensorId() {
        return sensorId;
    }

    public void setSensorId(Integer sensorId) {
        this.sensorId = sensorId;
    }

    public String getSensor() {
        return sensor;
    }

    public void setSensor(String sensor) {
        this.sensor = sensor;
    }

    public String getSensortype() {
        return sensortype;
    }

    public void setSensortype(String sensortype) {
        this.sensortype = sensortype;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public Integer getControllerId() {
        return controllerId;
    }

    public void setControllerId(Integer controllerId) {
        this.controllerId = controllerId;
    }

    public String getController() {
        return controller;
    }

    public void setController(String controller) {
        this.controller = controller;
    }

    public String getLastDate() {
        return lastDate;
    }

    public void setLastDate(String lastDate) {
        this.lastDate = lastDate;
    }

    public String getValuetype() {
        return valuetype;
    }

    public void setValuetype(String valuetype) {
        this.valuetype = valuetype;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public Integer getTypevalueid() {
        return typevalueid;
    }

    public void setTypevalueid(Integer typevalueid) {
        this.typevalueid = typevalueid;
    }

    public String getDatavalue() {
        return datavalue;
    }

    public void setDatavalue(String datavalue) {
        this.datavalue = datavalue;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }
}
