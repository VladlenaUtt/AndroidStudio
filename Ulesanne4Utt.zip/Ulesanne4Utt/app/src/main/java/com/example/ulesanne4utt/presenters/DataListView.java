package com.example.ulesanne4utt.presenters;

import java.util.List;

public interface DataListView<T> {
    void showData(List<T> items);
    void showError();

}
