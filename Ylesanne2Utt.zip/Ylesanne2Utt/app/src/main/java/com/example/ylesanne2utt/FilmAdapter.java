package com.example.ylesanne2utt;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class FilmAdapter extends RecyclerView.Adapter<FilmAdapter.FilmViewHolder> {
    private List<Film> films;
    private Context context;

    public FilmAdapter(Context context, List<Film> films) {
        this.context = context;
        this.films = films;
    }

    public static class FilmViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;
        public TextView textView;
        LinearLayout parentlayout;

        public FilmViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageViewFilm);
            textView = itemView.findViewById(R.id.textViewFilm);
            parentlayout = itemView.findViewById(R.id.parentLayout);
        }
    }

    @NonNull
    @Override
    public FilmViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_film, parent, false);
        FilmViewHolder viewHolder = new FilmViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull FilmViewHolder holder, final int position) {
        Film film = films.get(position);
        String imageUri = films.get(position).getPoster();
        Picasso.get().load(imageUri).into(holder.imageView);
        holder.textView.setText(films.get(position).getTitle());
        holder.parentlayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, FilmInfo.class);
                intent.putExtra("title", films.get(position).getTitle());
                context.startActivity(intent);
            }
        });
    }

    // @Override
    public int getItemCount() {
        return films.size();
    }
}
