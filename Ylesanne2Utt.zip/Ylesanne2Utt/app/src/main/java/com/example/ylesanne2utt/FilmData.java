package com.example.ylesanne2utt;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class FilmData {

    public static List<Film> films = new ArrayList<>();
    Context context;

    public FilmData(Context context) {
        this.context = context;
        String jsonFileString = getJsonFromAssets("films");
        Gson gson = new Gson();
        Type listFilmType = new TypeToken<List<Film>>() {
        }.getType();
        films = gson.fromJson(jsonFileString, listFilmType);
    }

    public List<Film> getAllFilms() {

        return films;
    }

    public List<String> getAllGenres() {
        Set<String> genres = new TreeSet<>();
        for (Film b : films) {
            for (String c : b.getGenre()) {
                genres.add(c);
            }
        }
        return new ArrayList<>(genres);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public static List<Film> getFilmsByGenres(final String genres) {
        List<Film> list = new ArrayList<>();
        for (Film f : films) {
            if (f.getGenre().contains(genres)) {
                list.add(f);
                Log.e("film: ", f.getTitle());
            }
        }
        return list;
    }
    protected static Film getFilmsByTitle(String title) {
        for (Film f : films) {
            if (f.getTitle().contains(title))
                return f;
            Log.e("filmTitle: ",f.getTitle());
        }
        return null;
    }
   public static List<Film> getFilmByID(String movieID){
        for (Film f : films) {
            if (f.getImdbID() == movieID) {
                Log.e("title: ", f.getImdbID());
                return (List<Film>) f;

            }
        }

       return null;
   }

    private String getJsonFromAssets(String fileName) {
        String jsonString;
        try {
            InputStream is = context.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            jsonString = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return jsonString;
    }
}
