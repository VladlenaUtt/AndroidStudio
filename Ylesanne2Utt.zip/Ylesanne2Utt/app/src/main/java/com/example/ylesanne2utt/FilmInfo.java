package com.example.ylesanne2utt;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;


public class FilmInfo extends AppCompatActivity {

    ImageView poster;
    TextView filmTitle;
    TextView filmDirector;
    TextView filmDescription;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_info);
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        poster = findViewById(R.id.imageViewPoster);
        filmTitle = findViewById(R.id.textViewTitle);
        filmDirector = findViewById(R.id.textViewDirector);
        filmDescription = findViewById(R.id.textViewDescription);
        Film film= (Film) FilmData.getFilmsByTitle(title);

    if (film!=null) {
        Picasso.get().load(film.getPoster()).into(poster);
        filmTitle.setText(title);
        filmDirector.setText(film.getDirector());
        filmDescription.setText(film.getPlot());
            }
        }
    }
