package com.example.ylesanne2utt;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FilmList extends AppCompatActivity {
    private ListView listViewBooks;
    private TextView textViewCategory;
    private RecyclerView recyclerViewFilms;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;

    @SuppressLint("StringFormatInvalid")
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_list);
        Intent intent = getIntent();
        String genres = intent.getStringExtra("genres");
        Log.e("genres: ", genres);
        textViewCategory = findViewById(R.id.textViewGenre);
        textViewCategory.setText(String.format("List of films ", genres));
        FilmData fd = new FilmData(this);
        final List<Film> films = fd.getFilmsByGenres(genres);

        Log.e("films.size: ", String.valueOf(films.size()));
        if (films.size() > 0) {
            recyclerViewFilms = findViewById(R.id.recyclerViewFilms);
            adapter = new FilmAdapter(this, films);
            layoutManager = new LinearLayoutManager(this);
            recyclerViewFilms.setAdapter(adapter);
            recyclerViewFilms.setLayoutManager(layoutManager);
        } else {
            Toast.makeText(getApplicationContext(), "No films in the genre " + genres, Toast.LENGTH_LONG).show();
        }
    }
}



