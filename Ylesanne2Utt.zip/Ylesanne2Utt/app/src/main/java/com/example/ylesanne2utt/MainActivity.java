package com.example.ylesanne2utt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;


public class MainActivity extends AppCompatActivity {

    ListView listGenre;
    FilmData fd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fd= new FilmData(this);
        listGenre = findViewById(R.id.listViewGenre);
        final List<String> categories = fd.getAllGenres();

        ArrayAdapter<String> genreAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, fd.getAllGenres());
        listGenre.setAdapter(genreAdapter);
        listGenre.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent (getApplicationContext(), FilmList.class);
                intent.putExtra("genres", categories.get(position));
                startActivity(intent);

            }
        });
    }
}
/*
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FilmData fd = new FilmData(this);
        List<Film> films = fd.getAllFilms();
        for (Film b : films) {
            Log.i("MyLog", b.getTitle());
        }
        List<String> genres = fd.getAllGenres();
        for (String c : genres) {
            Log.i("MyLog", c);
        }
    }
}
 */





