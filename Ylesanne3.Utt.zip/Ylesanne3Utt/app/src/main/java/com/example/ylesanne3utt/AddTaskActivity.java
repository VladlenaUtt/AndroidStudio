package com.example.ylesanne3utt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class AddTaskActivity extends AppCompatActivity {

    private EditText editTextTask, editTextDesc, editTextFinishBy;

    private TextView thedate;
    Spinner spinner;
    SeekBar seekbarpriority;
    private  static final String TAG = "CalendarActivity";
    private CalendarView mCalendarView;

    private String[] categories = {
            "Sport",
            "Family",
            "Shop",
            "School",
            "Work",
            "Hobby",
            "Fun",
            "Other"
    };

    public ArrayList<String> spinnerList = new ArrayList<> (Arrays.asList(categories));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        editTextTask = findViewById(R.id.editTextTask);
        editTextDesc = findViewById(R.id.editTextDesc);
        thedate = (TextView) findViewById(R.id.date);
        spinner = findViewById(R.id.categories_spinner);
        seekbarpriority = findViewById(R.id.seekBarPriority);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, spinnerList);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            String selected = adapterView.getItemAtPosition(i).toString();
            Intent intent = new Intent(AddTaskActivity.this, UpdateTaskActivity.class);
            intent.putExtra("categories", selected);
           // Log.e("My app", selected);
        }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        seekbarpriority.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressChangedValue = 0;

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue = progress;
                Intent intent = new Intent(AddTaskActivity.this, MainActivity.class);
                intent.putExtra("priority", progressChangedValue);
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(AddTaskActivity.this, "Priority is :" + progressChangedValue,
                        Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.button_save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveTask();
            }
        });

        mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView CalendarView, int year, int month, int dayOfMonth) {
                String date = year + "/" + month + "/"+ dayOfMonth ;
                Log.e(TAG, "onSelectedDayChange: yyyy/mm/dd:" + date);
                thedate.setText(date);
            }
        });
    }

    private void saveTask() {
        final String sTask = editTextTask.getText().toString().trim();
        final String sDesc = editTextDesc.getText().toString().trim();
        final String sDate = thedate.getText().toString().trim();
        final String sCategory = spinner.getSelectedItem().toString();
        final int sPriority = seekbarpriority.getProgress();

        if (sTask.isEmpty()) {
            editTextTask.setError("Task required");
            editTextTask.requestFocus();
            return;
        }
        if (sDesc.isEmpty()) {
            editTextDesc.setError("Desc required");
            editTextDesc.requestFocus();
            return;
        }
        if (sDate.isEmpty()) {
            thedate.setError("The date required");
            thedate.requestFocus();
            return;
        }
        if (sCategory.isEmpty()) {
            thedate.setError("The category required");
            thedate.requestFocus();
            return;
        }


        class SaveTask extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {

                Week week = new Week();
                week.setTask(sTask);
                week.setDesc(sDesc);
                week.setFinished(false);
                week.setDate(sDate);
                week.setCategory(sCategory);
                week.setPriority(sPriority);

                DBClient.getInstance(getApplicationContext()).getAppDatabase()
                        .weekDao()
                        .insert(week);
                return null;
            }
            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                finish();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG).show();
            }
        }

        SaveTask st = new SaveTask();
        st.execute();
    }
}

