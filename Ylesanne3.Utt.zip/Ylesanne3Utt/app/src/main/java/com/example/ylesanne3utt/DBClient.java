package com.example.ylesanne3utt;

import android.content.Context;

import androidx.room.Room;

public class DBClient {
    private Context mCtx;
    private static DBClient mInstance;

    private MyDatabase myDatabase;

    private DBClient(Context mCtx) {
        this.mCtx = mCtx;

        myDatabase = Room.databaseBuilder(mCtx, MyDatabase.class, "MyToDos").build();
    }

    public static synchronized DBClient getInstance(Context mCtx) {
        if (mInstance == null) {
            mInstance = new DBClient(mCtx);
        }
        return mInstance;
    }

    public MyDatabase getAppDatabase() {
        return myDatabase;
    }
}
