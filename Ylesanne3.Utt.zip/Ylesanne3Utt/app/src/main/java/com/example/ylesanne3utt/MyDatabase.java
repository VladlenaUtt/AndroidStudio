package com.example.ylesanne3utt;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Week.class}, version = 1)
public abstract class MyDatabase extends RoomDatabase {
    public abstract WeekDAO weekDao();
}
