package com.example.ylesanne3utt;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TasksAdapter extends RecyclerView.Adapter<TasksAdapter.TasksViewHolder> {
    private Context mCtx;
    private List<Week> weekList;

    public TasksAdapter(Context mCtx, List<Week> weekList) {
        this.mCtx = mCtx;
        this.weekList = weekList;
    }

    @Override
    public TasksViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mCtx).inflate(R.layout.recyclerview_tasks, parent, false);
        return new TasksViewHolder(view);
    }


    @Override
    public void onBindViewHolder(TasksViewHolder holder, int position) {
        Week w = weekList.get(position);
        holder.textViewTask.setText("Task name: " + w.getTask());
        holder.textViewDesc.setText("Task description: " + w.getDesc());
        holder.textViewDate.setText("Date: " + w.getDate());
        holder.textViewCategory.setText("Category: " + w.getCategory());
        holder.textViewPriority.setText("Priority: " + String.valueOf(w.getPriority()));

        if (w.isFinished())
            holder.textViewStatus.setText("Completed");
        else
            holder.textViewStatus.setText("Not Completed");
    }
    @Override
    public int getItemCount() {
        return weekList.size();
    }

    class TasksViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView textViewStatus, textViewTask, textViewDesc, textViewDate, textViewCategory, textViewPriority;

        public TasksViewHolder(View itemView) {
            super(itemView);

            textViewStatus = itemView.findViewById(R.id.textViewStatus);
            textViewTask = itemView.findViewById(R.id.textViewTask);
            textViewDesc = itemView.findViewById(R.id.textViewDesc);
            textViewDate = itemView.findViewById(R.id.date);
            textViewCategory = itemView.findViewById(R.id.textViewCategory);
            textViewPriority = itemView.findViewById(R.id.textViewPriority);
            itemView.setOnClickListener(this);

        }
        @Override
        public void onClick(View view) {
            Week week = weekList.get(getAdapterPosition());

            Intent intent = new Intent(mCtx, UpdateTaskActivity.class);
            intent.putExtra("week", week);
            mCtx.startActivity(intent);
        }
    }
}