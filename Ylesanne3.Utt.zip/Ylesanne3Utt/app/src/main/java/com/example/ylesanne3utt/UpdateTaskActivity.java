package com.example.ylesanne3utt;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class UpdateTaskActivity extends AppCompatActivity {

    private EditText editTextTask, editTextDesc;
    private CheckBox checkBoxFinished;
    private TextView thedate;
    SeekBar seekbarpriority;
    Spinner spinner;
    TextView categorieschosen;
    private CalendarView mCalendarView;

    private String[] categories = {
            "Sport",
            "Family",
            "Shop",
            "School",
            "Work",
            "Hobby",
            "Fun",
            "Other"

    };
    public ArrayList<String> spinnerList = new ArrayList<>(Arrays.asList(categories));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_task);


        editTextTask = findViewById(R.id.editTextTask);
        editTextDesc = findViewById(R.id.editTextDesc);
        checkBoxFinished = findViewById(R.id.checkBoxFinished);
        thedate = (TextView) findViewById(R.id.date);
        spinner = findViewById(R.id.categories_spinner);
        categorieschosen = findViewById(R.id.textViewCategory);
        seekbarpriority = findViewById(R.id.seekBarPriority);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, spinnerList);


        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selected = adapterView.getItemAtPosition(i).toString();
                Intent intent = new Intent(getApplicationContext(), UpdateTaskActivity.class);
                intent.putExtra("categories", selected);
                Log.e("My app", selected);
                spinner.setSelection(i);
                //Log.e("My app", String.valueOf(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        seekbarpriority.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressChangedValue = 0;

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue = progress;
                Intent intent = new Intent(UpdateTaskActivity.this, MainActivity.class);
                intent.putExtra("priority", progressChangedValue);
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(UpdateTaskActivity.this, "Priority is :" + progressChangedValue,
                        Toast.LENGTH_SHORT).show();
            }
        });

        final Week task = (Week) getIntent().getSerializableExtra("week");
        loadTask(task);

        findViewById(R.id.button_update).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Clicked", Toast.LENGTH_LONG).show();
                updateTask(task);
            }
        });

        Intent intent = new Intent();


        findViewById(R.id.button_delete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(UpdateTaskActivity.this);
                builder.setTitle("Are you sure?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        deleteTask(task);
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                AlertDialog ad = builder.create();
                ad.show();
            }
        });

        mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView CalendarView, int year, int month, int dayOfMonth) {
                String date = year + "/" + month + "/" + dayOfMonth;
                thedate.setText(date);
            }
        });
    }

    private void loadTask(Week week) {
        editTextTask.setText(week.getTask());
        editTextDesc.setText(week.getDesc());
        checkBoxFinished.setChecked(week.isFinished());
        thedate.setText(week.getDate());
        categorieschosen.setText(week.getCategory());
        seekbarpriority.setProgress(week.getPriority());

    }

    private void updateTask(final Week week) {
        final String sTask = editTextTask.getText().toString().trim();
        final String sDesc = editTextDesc.getText().toString().trim();
        final String sDate = thedate.getText().toString().trim();
        final String sCategory = categorieschosen.getText().toString().trim();
        final String sSpinner = spinner.getSelectedItem().toString();
        final int sPriority =  seekbarpriority.getProgress();

        if (sTask.isEmpty()) {
            editTextTask.setError("Task required");
            editTextTask.requestFocus();
            return;
        }

        if (sDesc.isEmpty()) {
            editTextDesc.setError("Desc required");
            editTextDesc.requestFocus();
            return;
        }
        if (sDate.isEmpty()) {
            thedate.setError("The date required");
            thedate.requestFocus();
            return;
        }

        class UpdateTask extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                week.setTask(sTask);
                week.setDesc(sDesc);
                week.setFinished(checkBoxFinished.isChecked());
                week.setDate(sDate);
                week.setCategory(sCategory);
                week.setCategory(sSpinner);
                week.setPriority(sPriority);
                DBClient.getInstance(getApplicationContext()).getAppDatabase()
                        .weekDao()
                        .update(week);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_LONG).show();
                finish();
                startActivity(new Intent(UpdateTaskActivity.this, MainActivity.class));
            }
        }

        UpdateTask ut = new UpdateTask();
        ut.execute();
    }


    private void deleteTask(final Week week) {
        class DeleteTask extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                DBClient.getInstance(getApplicationContext()).getAppDatabase()
                        .weekDao()
                        .delete(week);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Toast.makeText(getApplicationContext(), "Deleted", Toast.LENGTH_LONG).show();
                finish();
                startActivity(new Intent(UpdateTaskActivity.this, MainActivity.class));
            }
        }

        DeleteTask dt = new DeleteTask();
        dt.execute();

    }

}