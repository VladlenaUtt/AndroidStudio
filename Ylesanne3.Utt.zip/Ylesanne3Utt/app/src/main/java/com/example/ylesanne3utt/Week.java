package com.example.ylesanne3utt;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity
public class Week implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "task")
    private String task;

    @ColumnInfo(name = "desc")
    private String desc;

    @ColumnInfo(name = "finished")
    private boolean finished;

    @ColumnInfo(name = "date")
    private String date;

    @ColumnInfo(name = "category")
    private String category;

    @ColumnInfo(name = "priority")
    private int priority;

    /*
     * Getters and Setters
     * */
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public boolean isFinished() {
        return finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public String getDate() {return date; }

    public void setDate(String date) {this.date = date; }

    public String getCategory() {return category; }

    public void setCategory(String category) {this.category = category; }

    public int getPriority() {return priority; }

    public void setPriority(int priority) {this.priority = priority; }
}
