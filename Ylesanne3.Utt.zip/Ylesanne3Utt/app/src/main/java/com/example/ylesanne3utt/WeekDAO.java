package com.example.ylesanne3utt;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeekDAO {


    @Query("SELECT * FROM Week")
    List<Week> getEvery();

    @Insert
    void insert(Week week);

    @Delete
    void delete(Week week);

    @Update
    void update(Week week);
}
